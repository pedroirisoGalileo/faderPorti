var searchData=
[
  ['debouncer_7',['Debouncer',['../class_debouncer.html',1,'Debouncer'],['../class_debouncer.html#a34c46ca04d4178933cc0049436d10fe6',1,'Debouncer::Debouncer()']]],
  ['duration_8',['duration',['../class_debouncer.html#a462994f1f9a20876b2ee239eeee97448',1,'Debouncer']]]
];
